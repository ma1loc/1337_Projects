

 this is (most of the) sprites from  my game LAB
 
 in case you never heard of it it's a little Wolf3D clone made in Flash AS3
 ( and you can play/download it for free: https://mutantleg.itch.io/lab )

 all these gfx is hereby public domain (CC0)
 (credit is not required but much appreciated indeed)
  
  game and graphics by Mutantleg (me)  (2015)

  
