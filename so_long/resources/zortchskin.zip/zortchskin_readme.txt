
world textures from my game Zortch
https://mutantleg.itch.io/zortch
https://store.steampowered.com/app/2443360/Zortch/

I tried to collect up the ones that might be useful in other games
these are now CC0 public domain

no credit is required but I appreciate if you give credit or just shill the game

also if you find an use for them you can tell me about it here: mutgame(at)gmail.com
